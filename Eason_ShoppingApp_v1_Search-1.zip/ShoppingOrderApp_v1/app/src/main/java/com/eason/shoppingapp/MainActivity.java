package com.eason.shoppingapp;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.Context;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    TextView cartCount, totalView;
    final ArrayList<Product> products = new ArrayList<>();
    final ArrayList<CartItem> cart = new ArrayList<>();

    int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    TextView tv(String text, float size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text); t.setTextSize(size); t.setTextColor(Color.rgb(25,25,25));
        t.setPadding(dp(12),dp(8),dp(12),dp(8));
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    Button btn(String text) {
        Button b = new Button(this); b.setText(text); b.setAllCaps(false);
        return b;
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        products.add(new Product("經典黑色 T-Shirt", 399, "👕"));
        products.add(new Product("電競戰隊帽", 299, "🧢"));
        products.add(new Product("桌面 RGB 燈", 699, "💡"));
        products.add(new Product("遊戲滑鼠墊", 249, "🖱️"));
        showHome();
    }

    void base(String title) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(248,248,248));
        LinearLayout bar = new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(8),dp(6),dp(8),dp(6)); bar.setBackgroundColor(Color.WHITE);
        TextView t = tv(title,22,true); bar.addView(t,new LinearLayout.LayoutParams(0,dp(56),1));
        Button cartBtn = btn("🛒 購物車");
        cartBtn.setOnClickListener(v -> showCart());
        bar.addView(cartBtn,new LinearLayout.LayoutParams(dp(120),dp(52)));
        root.addView(bar);
        ScrollView sv = new ScrollView(this);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(12),dp(12),dp(12),dp(24));
        sv.addView(content); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }

    void showHome() {
        base("Eason 商城");
        content.addView(tv("熱門商品",20,true));
        content.addView(tv("選擇商品並加入購物車",14,false));

        EditText search = new EditText(this);
        search.setHint("🔍 搜尋商品名稱");
        search.setSingleLine(true);
        search.setPadding(dp(14),dp(10),dp(14),dp(10));
        content.addView(search, new LinearLayout.LayoutParams(-1, dp(56)));

        LinearLayout productList = new LinearLayout(this);
        productList.setOrientation(LinearLayout.VERTICAL);
        content.addView(productList);

        Runnable renderProducts = new Runnable() {
            @Override public void run() {
                productList.removeAllViews();
                String keyword = search.getText().toString().trim().toLowerCase();
                int found = 0;

                for (Product p: products) {
                    if (!keyword.isEmpty() && !p.name.toLowerCase().contains(keyword)) continue;
                    found++;

                    LinearLayout card = new LinearLayout(MainActivity.this);
                    card.setOrientation(LinearLayout.VERTICAL);
                    card.setPadding(dp(12),dp(12),dp(12),dp(12));
                    card.setBackgroundColor(Color.WHITE);

                    TextView icon = tv(p.icon,42,false);
                    icon.setGravity(Gravity.CENTER);
                    card.addView(icon,new LinearLayout.LayoutParams(-1,dp(65)));
                    card.addView(tv(p.name,18,true));
                    card.addView(tv("NT$ " + p.price,16,false));

                    Button add = btn("加入購物車");
                    add.setOnClickListener(v -> {
                        addToCart(p);
                        Toast.makeText(MainActivity.this,"已加入購物車",Toast.LENGTH_SHORT).show();
                    });
                    card.addView(add);

                    LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1,-2);
                    cp.setMargins(0,0,0,dp(12));
                    productList.addView(card,cp);
                }

                if(found == 0) productList.addView(tv("找不到符合的商品 😕",17,true));
            }
        };

        search.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s,int start,int count,int after) {}
            public void onTextChanged(CharSequence s,int start,int before,int count) { renderProducts.run(); }
            public void afterTextChanged(android.text.Editable e) {}
        });

        renderProducts.run();
    }

    void addToCart(Product p) {
        for (CartItem c: cart) if(c.p==p){c.qty++; return;}
        cart.add(new CartItem(p,1));
    }

    int total() { int x=0; for(CartItem c:cart)x+=c.p.price*c.qty; return x; }

    void showCart() {
        base("購物車");
        if(cart.isEmpty()){
            content.addView(tv("購物車目前是空的 🛒",20,true));
            Button back=btn("回商品頁"); back.setOnClickListener(v->showHome()); content.addView(back); return;
        }
        for(CartItem c: new ArrayList<>(cart)) {
            LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout info=new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL);
            info.addView(tv(c.p.name,17,true)); info.addView(tv("NT$ "+c.p.price,14,false));
            row.addView(info,new LinearLayout.LayoutParams(0,-2,1));
            Button minus=btn("−"); Button qty=btn(String.valueOf(c.qty)); Button plus=btn("+");
            minus.setOnClickListener(v->{c.qty--; if(c.qty<=0)cart.remove(c); showCart();});
            plus.setOnClickListener(v->{c.qty++; showCart();});
            row.addView(minus,new LinearLayout.LayoutParams(dp(50),dp(50)));
            row.addView(qty,new LinearLayout.LayoutParams(dp(55),dp(50)));
            row.addView(plus,new LinearLayout.LayoutParams(dp(50),dp(50)));
            content.addView(row);
        }
        content.addView(tv("合計：NT$ "+total(),22,true));
        Button checkout=btn("前往填寫收件資料");
        checkout.setOnClickListener(v->showCheckout()); content.addView(checkout);
        Button back=btn("繼續購物"); back.setOnClickListener(v->showHome()); content.addView(back);
    }

    void showCheckout() {
        base("確認下單");
        content.addView(tv("訂單總額：NT$ "+total(),22,true));
        EditText name=new EditText(this); name.setHint("收件人姓名"); content.addView(name);
        EditText phone=new EditText(this); phone.setHint("手機號碼"); phone.setInputType(2); content.addView(phone);
        EditText address=new EditText(this); address.setHint("收件地址"); content.addView(address);
        content.addView(tv("付款方式",17,true));
        RadioGroup rg=new RadioGroup(this);
        String[] methods={"貨到付款","信用卡（示範）","LINE Pay（示範）"};
        for(String m:methods){RadioButton r=new RadioButton(this);r.setText(m);rg.addView(r);}
        ((RadioButton)rg.getChildAt(0)).setChecked(true); content.addView(rg);
        Button order=btn("✅ 確認下單");
        order.setOnClickListener(v->{
            if(name.getText().toString().trim().isEmpty() || phone.getText().toString().trim().isEmpty() || address.getText().toString().trim().isEmpty()){
                Toast.makeText(this,"請填寫完整收件資料",Toast.LENGTH_SHORT).show(); return;
            }
            cart.clear(); showSuccess();
        });
        content.addView(order);
        Button back=btn("返回購物車"); back.setOnClickListener(v->showCart()); content.addView(back);
    }

    void showSuccess() {
        base("下單完成");
        content.addView(tv("🎉 訂單已建立！",26,true));
        content.addView(tv("感謝你的購買。這是第一版示範，尚未串接真實金流與物流。",16,false));
        Button home=btn("回首頁"); home.setOnClickListener(v->showHome()); content.addView(home);
    }

    static class Product { String name,icon; int price; Product(String n,int p,String i){name=n;price=p;icon=i;} }
    static class CartItem { Product p; int qty; CartItem(Product p,int q){this.p=p;qty=q;} }
}